from flask import Flask, request, json, Response
from pymongo import MongoClient
import subprocess as sp
from bson.objectid import ObjectId
from bson import errors
import threading

connection_string = 'mongodb://localhost:27017'  # mongodb connection string
app = Flask(__name__)

# connect to the database
try:
    mongo = MongoClient(connection_string)
    db = mongo.get_database('test')
    collection = db.test1
    mongo.server_info()
except:
    print("can't connect to the database")


# function to execute the background task & save the output to database
def background_task(task):
    output = sp.run(task, shell=True, capture_output=True, text=True)
    collection.insert_one({'output': output.stdout})


# endpoint to add data to the database
@app.route('/add', methods=['POST'])
def add():
    obj_id = None
    data = request.json['cmd']
    collection.insert_one({'cmd': data})
    for i in collection.find({'cmd': data}):
        obj_id = str(i['_id'])

    # this thread will run in the background end execute the task
    threading.Thread(target=background_task, args=(data,)).start()

    return Response(
        response=json.dumps({'id': obj_id}),
        status=200,
        mimetype='application/json'
    )


# endpoint to get the output from database
@app.route('/get/<fileID>', methods=['GET'])
def get(fileID):
    try:
        output = None
        for i in collection.find({'_id': ObjectId(fileID)}):
            try:
                # if not i['output']:
                #     return json.dumps({'message': 'Invalid key'})
                output = i['output']
            except KeyError:
                return json.dumps({'message': 'Invalid key'})

        return Response(
            response=json.dumps({"message": output}),
            status=200,
            mimetype='application/json'
        )

    # if the entered id is invalid, instead of completely error out, it will throw a nice little message
    except errors.InvalidId:
        return Response(
            response=json.dumps({"message": "Invalid ID"}),
            status=500,
            mimetype="application/json"
        )


if __name__ == '__main__':
    app.run(host="0.0.0.0", port=9000)
