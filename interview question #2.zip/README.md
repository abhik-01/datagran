# Instructions

Run the command "docker build -t name of the app .", make sure to put the dot(.) at the end which will select the current directory.

I've created a local database in mongodb & named the database as "test" & the collection as "test1". To monitor the dataabse I've used mongodb compass.

After building the image, run the command "docker run -it -p 9000:9000 name of the app".

"-it" is for terminal mode & "-p" is to expose the port. Here in the flask app, I've selected port 9000, that's why we are using "-p 9000:9000" command. After this step a localhost url will show up & the flask app will start.

I've used postman for testing the api endpoints. To do so, copy the url address, then open postman, create a new request.

To add data to the database, select POST method in postman, paste the url & then write /add after the url as it will add the input data to the database. Select the body option & then select raw & then JSON as it will create a json input.

To get the output of the task from database, create a new request in postman, select GET method, enter the url & then write /get/(the id of the output stored in the database).